from summarizer import Summarizer

summarizer = Summarizer(api_key='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')

example_text = '''Once upon a time, in a quaint village nestled between rolling hills and lush forests, there lived a young girl named Lila. Lila was known throughout the village for her kindness and curiosity. She spent her days exploring the woods, searching for hidden treasures and secret pathways.

One crisp autumn morning, while wandering deep into the heart of the forest, Lila stumbled upon a mysterious clearing she had never seen before. In the center of the clearing stood an ancient oak tree, its branches reaching towards the sky like gnarled fingers. Beneath the tree lay a forgotten chest, covered in moss and vines.

With trembling hands, Lila pried open the chest and gasped in wonder at its contents: a shimmering amulet pulsating with otherworldly energy. As she reached out to touch it, a voice echoed in her mind, whispering of ancient prophecies and long-forgotten magic.

Determined to uncover the truth behind the amulet, Lila embarked on a journey that would take her far beyond the borders of her village. Along the way, she encountered mythical creatures, befriended unlikely allies, and faced countless trials and tribulations.

But through it all, Lila remained steadfast in her quest, fueled by her insatiable thirst for knowledge and her unwavering belief in the power of hope and friendship. And in the end, it was her courage and determination that allowed her to unlock the true potential of the amulet, bringing peace and prosperity to the land once more.

And so, Lila returned to her village, her heart filled with newfound wisdom and her spirit forever changed by her extraordinary adventure in the enchanted forest.'''













summary = summarizer.summarize(example_text, style = 'instagram post')

print(summary)