
from generator import Generator

gen = Generator(api_key='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')

story = gen.generate("the bird flew across the horizon")

print(story)